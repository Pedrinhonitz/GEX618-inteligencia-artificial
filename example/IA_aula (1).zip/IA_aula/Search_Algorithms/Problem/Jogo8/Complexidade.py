from enum import Enum


class Complexidade(Enum):
    Facil = 3
    Medio = 4
    Dificil = 5
